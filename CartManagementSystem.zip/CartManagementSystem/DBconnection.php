<?php
    $con = new mysqli("localhost","root","","cartmanagementsystem");
    if($con->connect_error)
    {
        die("connection failed" .$con->connect_error);
    }
?>