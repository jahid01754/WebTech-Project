<?php
    require 'DBconnection.php';

    $grand_total = 0;
    $allItems = '';
    $items = array();

    $sql = "SELECT CONCAT(product_name, '(',qty,')' ) AS ItemQty,total_price FROM cart";
    $stmt = $con->prepare($sql);
    
    #problem
    $stmt-> execute(); 
    
    
    $result = $stmt-> get_result();
    
    while($row = $result->fetch_assoc())
    {
        $grand_total += $row['total_price'];
        $items[] = $row['ItemQty'];
    }
    $allItems = implode(",", $items);
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckOut</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <link rel= "stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>
<body>

    <!--nav bar-->
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
    
    <a class="navbar-brand" href="index.php"><i class="fas fa-cart-alt"></i>&nbsp;&nbsp;Amazon</a>

    
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
    </button>

    
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ml-auto">
            <!--
            <li class="nav-item">
                <a class="nav-link active" href="index.php">Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Categories</a>
            </li>
            -->
            <li class="nav-item">
                <a class="nav-link" href="checkout.php">CheckOut</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cart.php">
                    <i class="fas fa-shopping-cart">
                        <span id="cart-item" class="badge badge-danger"></span>
                    </i>
                </a>
            </li> 
        </ul>
    </div> 
    </nav>

    
    
    
    <!--main portion-->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 px-4 pb-4">
                <h4 class="text-center text-info p-2">Complete your Order</h4>
                <div class="jumbotron"></div>
            </div> 
        </div>
    </div>

    
    
    
    
        <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


    <script type="text/javascript">
        $(document).ready(function(){

            load_cart_item_number();

            function load_cart_item_number()
            {
                $.ajax({
                    url:'action.php',
                    method: 'get',
                    data: {cartItem:"cart_item"},
                    success: function(response)
                    {
                        $("#cart-item").html(response);
                    }
                })
            }
        });
    </script>
</body>
</html>